#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"

int main(void)
{
    int pid;

    char *text = malloc(16 * sizeof(char));

    int f_pid = getpid();

    pid = fork();
    if (pid < 0) {
        printf("Fork failed\n");
        exit(1);
    }
    if (pid == 0) { 
        char *child_text;

        printf("Child size before mapping: %d\n", sbrk(0));
        child_text = (char *)map_shared_pages(f_pid, getpid(), (uint64)text, 16 * sizeof(char));
        if (child_text == (char *)-1) {
            printf("Failed to map shared memory\n");
            exit(1);
        }
        printf("Child size after mapping: %d\n", sbrk(0));
        strcpy(child_text, "Hello daddy");

        if (unmap_shared_pages((uint64)child_text, 16 * sizeof(char)) < 0) {
            printf("Child Failed to unmap shared memory\n");
            exit(1);
        }
        printf("Child size after unmapping: %d\n", sbrk(0));
        char* check = malloc(100000 * sizeof(char));
        printf("Child size after malloc: %d\n", sbrk(0));
        free(check);
        exit(0);
    } else { 
        wait(0); 

        printf("%s\n", text);
        free(text);
    }

    exit(0);
}
