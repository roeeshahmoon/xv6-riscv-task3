#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

#define NUM_CHILDREN 4
#define BUFFER_SIZE 4096  // PGSIZE
#define MESSAGE_LEN 20    // Fixed message length for simplicity

// Header structure: 16-bit child index + 16-bit message length
struct log_header {
    uint16 child_index;
    uint16 message_length;
};


// Simple string length function
int str_len(const char* s) {
    int len = 0;
    while (s[len] != '\0') len++;
    return len;
}

// Simple memory copy function
void mem_copy(void* dst, const void* src, int n) {
    char* d = (char*)dst;
    const char* s = (const char*)src;
    for (int i = 0; i < n; i++) {
        d[i] = s[i];
    }
}

void child_process(int child_index, char* shared_buffer) {
    char message[MESSAGE_LEN + 1];
    int msg_count = 0;
    
    // Create messages with child index - using simple string construction
    for (int i = 0; i < 3; i++) {  // Each child writes 3 messages
        message[0] = 'C';
        message[1] = 'h';
        message[2] = 'i';
        message[3] = 'l';
        message[4] = 'd';
        message[5] = ' ';
        message[6] = '0' + child_index;
        message[7] = ' ';
        message[8] = 'm';
        message[9] = 's';
        message[10] = 'g';
        message[11] = ' ';
        message[12] = '0' + (i + 1);
        
        // Pad with spaces to make all messages same length
        for (int j = 13; j < MESSAGE_LEN; j++) {
            message[j] = ' ';
        }
        message[MESSAGE_LEN] = '\0';
        
        int msg_len = MESSAGE_LEN;
        
        // Find a free spot in the buffer
        char* current_addr = shared_buffer;
        int attempts = 0;
        
        while (current_addr < shared_buffer + BUFFER_SIZE - sizeof(struct log_header) - msg_len) {
            // Check if we can fit the header + message
            if (current_addr + sizeof(struct log_header) + msg_len >= shared_buffer + BUFFER_SIZE) {
                return;  // Buffer full, exit quietly
            }
            
            struct log_header* header = (struct log_header*)current_addr;
            
            // Try to claim this spot atomically
            struct log_header new_header = {child_index, msg_len};
            struct log_header zero_header = {0, 0};
            
            // Use atomic compare-and-swap to claim the spot
            uint32 old_val = __sync_val_compare_and_swap((uint32*)header, *(uint32*)&zero_header, *(uint32*)&new_header);
            
            if (old_val == 0) {  // Successfully claimed the spot
                // Write the message after the header
                char* msg_addr = current_addr + sizeof(struct log_header);
                mem_copy(msg_addr, message, msg_len);
                
                msg_count++;
                break;
            } else {
                // Spot was taken, move to next potential location
                struct log_header* existing = (struct log_header*)&old_val;
                current_addr += sizeof(struct log_header) + existing->message_length;
                
                // Align to 4-byte boundary
                current_addr = (char*)(((uint64)current_addr + 3) & ~3);
            }
            
            attempts++;
            if (attempts > 100) {  // Prevent infinite loop
                break;
            }
        }
        
        // Small delay to allow other processes to work
        sleep(1);
    }
    
    // Only print completion message without details to reduce output collision
}

void parent_process(char* shared_buffer) {
    printf("Parent: Starting to read messages from shared buffer\n");
    
    char* current_addr = shared_buffer;
    int messages_read = 0;
    
    // Give children time to write some messages
    sleep(2);
    
    while (current_addr < shared_buffer + BUFFER_SIZE - sizeof(struct log_header)) {
        struct log_header* header = (struct log_header*)current_addr;
        
        // Check if there's a valid message
        if (header->child_index == 0 && header->message_length == 0) {
            // No message here, move to next aligned position
            current_addr += sizeof(struct log_header);
            current_addr = (char*)(((uint64)current_addr + 3) & ~3);
            continue;
        }
        
        // Validate message length
        if (header->message_length > MESSAGE_LEN || 
            current_addr + sizeof(struct log_header) + header->message_length >= shared_buffer + BUFFER_SIZE) {
            printf("Parent: Invalid message length or buffer overflow, stopping\n");
            break;
        }
        
        // Read the message
        char message[MESSAGE_LEN + 1];
        char* msg_addr = current_addr + sizeof(struct log_header);
        mem_copy(message, msg_addr, header->message_length);
        message[header->message_length] = '\0';  // Null terminate
        
        printf("Parent read from child %d: %s\n", header->child_index, message);
        messages_read++;
        
        // Move to next message location
        current_addr += sizeof(struct log_header) + header->message_length;
        current_addr = (char*)(((uint64)current_addr + 3) & ~3);
    }
    
    printf("Parent: Finished reading %d messages\n", messages_read);
}

int main(int argc, char *argv[]) {
    printf("Starting multi-process logging test with %d children\n", NUM_CHILDREN);
    
    // Allocate shared buffer in parent
    char* shared_buffer = (char*)malloc(BUFFER_SIZE);
    if (!shared_buffer) {
        printf("Failed to allocate shared buffer\n");
        exit(1);
    }
    
    // Initialize buffer to zero
    for (int i = 0; i < BUFFER_SIZE; i++) {
        shared_buffer[i] = 0;
    }
    
    int parent_pid = getpid();
    
    // Fork child processes
    for (int i = 0; i < NUM_CHILDREN; i++) {
        int pid = fork();
        if (pid == 0) {
            // Child process
            // Map shared buffer from parent
            uint64 child_buffer_addr = map_shared_pages(parent_pid, getpid(), (uint64)shared_buffer, BUFFER_SIZE);
            if (child_buffer_addr == 0) {
                exit(1);
            }
            
            // Give child a moment to avoid output collision
            sleep(i);
            
            // Start writing to shared buffer
            child_process(i, (char*)child_buffer_addr);
            
            // Unmap shared buffer before exiting
            unmap_shared_pages(child_buffer_addr, BUFFER_SIZE);
            exit(0);
        } else if (pid > 0) {
            // Reduce output noise - just track that we forked successfully
            continue;
        } else {
            printf("Fork failed for child %d\n", i);
            exit(1);
        }
    }
    
    // Give children time to map and start writing
    sleep(3);
    
    // Parent reads messages
    parent_process(shared_buffer);
    
    // Wait for all children to complete
    for (int i = 0; i < NUM_CHILDREN; i++) {
        int status;
        wait(&status);
    }
    
    // Clean up
    free(shared_buffer);
    
    printf("Multi-process logging test completed successfully\n");
    return 0;
}